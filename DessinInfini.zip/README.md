# Dessin Infini

Application Android de dessin où l'on peut zoomer quasi à l'infini dans le
dessin et continuer à dessiner avec précision, même très zoomé.

## Comment ça marche (zoom infini)

Les traits ne sont pas stockés en pixels mais en **coordonnées "monde"**
(nombres `Double`). L'affichage recalcule à chaque frame la position écran
d'un point en le rapportant à la caméra actuelle (`point - caméra`), ce qui
garde toujours des nombres petits et précis, même après un zoom énorme.
En pratique, on peut zoomer jusqu'à environ 10^14 fois avant de sentir une
perte de précision (limite physique des nombres `Double`).

- 1 doigt : dessiner
- 2 doigts : pincer pour zoomer / déplacer la vue
- Boutons **Fin / Moyen / Épais** : change l'épaisseur du prochain trait
- Bouton **Fond** : fait défiler quelques couleurs de fond
- Bouton **Grille** : affiche/masque une grille de repère qui se réadapte
  automatiquement au niveau de zoom (elle choisit toujours un espacement
  proche d'une puissance de 10 par rapport à l'échelle courante)

## Sauvegarde : le format `.inF`

Le dessin (traits, épaisseurs, couleurs, fond, grille, position de caméra)
peut être sauvegardé dans un fichier au format **`.inF`** ("Infinite
Image"), un format ouvert et texte (JSON) pensé pour être relu par
n'importe quelle application compatible — y compris de futures apps que tu
créeras (visionneuse, autre éditeur, etc.).

- **Sauver** : ouvre le sélecteur de fichiers Android pour choisir où créer
  le fichier `.inF`.
- **Ouvrir** : ouvre le sélecteur de fichiers Android pour charger un
  fichier `.inF` existant (remplace le dessin courant).
- L'app peut aussi s'ouvrir automatiquement si un fichier `.inF` est ouvert
  depuis un gestionnaire de fichiers (association enregistrée dans le
  `AndroidManifest.xml`).

### Spécification du format `.inF` (version 1)

Fichier texte UTF-8 contenant un objet JSON :

```json
{
  "format": "InfiniteImage",
  "version": 1,
  "background": {
    "color": "#FFFFFFFF",
    "grid": true
  },
  "camera": {
    "x": 0.0,
    "y": 0.0,
    "scale": 1.0
  },
  "strokes": [
    {
      "color": "#FF000000",
      "width": 0.5,
      "points": [[0.0, 0.0], [1.2, 3.4], [2.0, 5.0]]
    }
  ]
}
```

Règles pour rester compatible entre applications :

- `format` doit valoir `"InfiniteImage"`.
- `version` est un entier, incrémenté à chaque évolution incompatible du
  format (les lecteurs doivent ignorer les champs qu'ils ne connaissent pas
  plutôt que d'échouer, pour rester compatibles avec des versions futures).
- Les couleurs sont des chaînes hexadécimales **ARGB** : `#AARRGGBB`.
- `camera.scale` est le niveau de zoom au moment de la sauvegarde ; `x`/`y`
  sont la position du centre de la caméra en coordonnées monde.
- **`width` (épaisseur d'un trait) est exprimée en unité MONDE, pas en
  pixels.** C'est ce qui permet à un fichier `.inF` d'être rouvert et
  zoomé à l'infini par n'importe quelle app : plus on zoome, plus le trait
  grossit proportionnellement, exactement comme le reste du dessin.
- `points` est une liste de `[x, y]` en coordonnées monde (nombres à
  virgule flottante, pas de limite de précision imposée par le format —
  seule la précision du type numérique utilisé par l'app qui lit/écrit le
  fichier s'applique, un `Double` en pratique).

Type MIME suggéré pour ce format : `application/x-infinite-image`.

## Publicité

Le projet intègre Google AdMob (bannière en bas de l'écran) avec les
**identifiants de test officiels de Google**. Avant de publier
l'application, remplace :

- `ca-app-pub-3940256099942544~3347511713` dans `AndroidManifest.xml`
- `ca-app-pub-3940256099942544/6300978111` dans `activity_main.xml`

par tes propres identifiants AdMob (créés sur https://admob.google.com).

## Compiler l'APK sur GitHub

1. Crée un dépôt GitHub et pousse tout le contenu de ce dossier à la racine
   du dépôt (le fichier `.github/workflows/build.yml` doit se trouver à
   `.github/workflows/build.yml` dans le dépôt).
2. Va dans l'onglet **Actions** du dépôt : le workflow "Build APK" se lance
   automatiquement à chaque push sur `main` (ou lance-le manuellement via
   "Run workflow").
3. Une fois terminé, télécharge l'APK dans l'artifact **DessinInfini-debug-apk**
   généré par le job.

## Compiler en local (optionnel)

```bash
./gradlew assembleDebug
```
L'APK se trouve ensuite dans `app/build/outputs/apk/debug/app-debug.apk`.
