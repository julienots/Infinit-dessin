package com.dessininfini.app

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {

    private lateinit var canvasView: InfiniteCanvasView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MobileAds.initialize(this) {}

        canvasView = findViewById(R.id.canvasView)

        findViewById<Button>(R.id.btnNoir).setOnClickListener {
            canvasView.currentColor = Color.BLACK
        }
        findViewById<Button>(R.id.btnRouge).setOnClickListener {
            canvasView.currentColor = Color.RED
        }
        findViewById<Button>(R.id.btnBleu).setOnClickListener {
            canvasView.currentColor = Color.BLUE
        }
        findViewById<Button>(R.id.btnVert).setOnClickListener {
            canvasView.currentColor = Color.rgb(0, 150, 0)
        }
        findViewById<Button>(R.id.btnUndo).setOnClickListener {
            canvasView.undo()
        }
        findViewById<Button>(R.id.btnRedo).setOnClickListener {
            canvasView.redo()
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            canvasView.clearAll()
        }
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            canvasView.resetView()
        }

        val adView = findViewById<AdView>(R.id.adView)
        adView.loadAd(AdRequest.Builder().build())
    }
}
