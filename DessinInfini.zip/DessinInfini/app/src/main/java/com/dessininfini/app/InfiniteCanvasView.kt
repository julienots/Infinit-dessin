package com.dessininfini.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/**
 * Vue de dessin à "zoom infini".
 *
 * Toutes les coordonnées des traits sont stockées en "coordonnées monde" (Double),
 * jamais en pixels écran. On ne convertit en pixels (Float) qu'au moment du rendu,
 * en soustrayant d'abord la position de la caméra : les nombres manipulés par
 * Canvas restent donc toujours petits et précis, même après un zoom énorme,
 * puisque le point affiché est toujours proche du centre de la caméra.
 *
 * Limite pratique : la précision d'un Double (~15-17 chiffres significatifs)
 * permet de zoomer jusqu'à environ 10^14 fois sans perte visible de précision,
 * ce qui donne l'impression d'un dessin infiniment profond.
 */
class InfiniteCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    data class DPoint(val x: Double, val y: Double)

    data class Stroke(
        val color: Int,
        val widthWorld: Double,
        val points: MutableList<DPoint> = mutableListOf()
    )

    private val strokes = mutableListOf<Stroke>()
    private val redoStack = mutableListOf<Stroke>()
    private var currentStroke: Stroke? = null

    /** Position de la caméra en coordonnées monde (centre de l'écran). */
    var camX = 0.0
    var camY = 0.0

    /** Echelle : pixels écran par unité "monde". */
    var scale = 1.0
        private set

    var currentColor = Color.BLACK

    private val minScale = 1e-6
    private val maxScale = 1e14

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {

            private var lastFocusX = 0f
            private var lastFocusY = 0f
            private var first = true

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                lastFocusX = detector.focusX
                lastFocusY = detector.focusY
                first = true
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val fx = detector.focusX
                val fy = detector.focusY

                if (first) {
                    lastFocusX = fx
                    lastFocusY = fy
                    first = false
                }

                // Point du monde sous le doigt AVANT le changement d'échelle.
                val worldXBefore = camX + (lastFocusX - width / 2.0) / scale
                val worldYBefore = camY + (lastFocusY - height / 2.0) / scale

                var newScale = scale * detector.scaleFactor.toDouble()
                if (newScale < minScale) newScale = minScale
                if (newScale > maxScale) newScale = maxScale
                scale = newScale

                // On replace la caméra pour que ce même point reste sous le doigt.
                camX = worldXBefore - (fx - width / 2.0) / scale
                camY = worldYBefore - (fy - height / 2.0) / scale

                // Déplacement (pan à deux doigts).
                camX -= (fx - lastFocusX) / scale
                camY -= (fy - lastFocusY) / scale

                lastFocusX = fx
                lastFocusY = fy

                invalidate()
                return true
            }
        }
    )

    private fun screenToWorld(sx: Float, sy: Float): DPoint {
        val wx = camX + (sx - width / 2.0) / scale
        val wy = camY + (sy - height / 2.0) / scale
        return DPoint(wx, wy)
    }

    /** Renvoie les coordonnées écran (Float) d'un point monde, relatives à la caméra actuelle. */
    private fun worldToScreen(p: DPoint): FloatArray {
        val sx = ((p.x - camX) * scale + width / 2.0).toFloat()
        val sy = ((p.y - camY) * scale + height / 2.0).toFloat()
        return floatArrayOf(sx, sy)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        if (event.pointerCount >= 2) {
            // Deux doigts = navigation (zoom/déplacement), on annule un trait en cours.
            currentStroke = null
            return true
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val w = screenToWorld(event.x, event.y)
                val widthWorld = 6.0 / scale
                val stroke = Stroke(currentColor, widthWorld)
                stroke.points.add(w)
                currentStroke = stroke
                redoStack.clear()
            }

            MotionEvent.ACTION_MOVE -> {
                currentStroke?.points?.add(screenToWorld(event.x, event.y))
                invalidate()
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                currentStroke?.let {
                    if (it.points.size == 1) {
                        it.points.add(it.points[0])
                    }
                    strokes.add(it)
                }
                currentStroke = null
                invalidate()
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.WHITE)

        for (stroke in strokes) drawStroke(canvas, stroke)
        currentStroke?.let { drawStroke(canvas, it) }
    }

    private fun drawStroke(canvas: Canvas, stroke: Stroke) {
        if (stroke.points.isEmpty()) return

        paint.color = stroke.color
        val strokeWidthPx = (stroke.widthWorld * scale).toFloat()
        paint.strokeWidth = if (strokeWidthPx < 1.5f) 1.5f else strokeWidthPx

        if (stroke.points.size == 1) {
            val p = worldToScreen(stroke.points[0])
            canvas.drawPoint(p[0], p[1], paint)
            return
        }

        val path = Path()
        val first = worldToScreen(stroke.points[0])
        path.moveTo(first[0], first[1])
        for (i in 1 until stroke.points.size) {
            val p = worldToScreen(stroke.points[i])
            path.lineTo(p[0], p[1])
        }
        canvas.drawPath(path, paint)
    }

    fun clearAll() {
        strokes.clear()
        redoStack.clear()
        currentStroke = null
        invalidate()
    }

    fun undo() {
        if (strokes.isNotEmpty()) {
            redoStack.add(strokes.removeAt(strokes.size - 1))
            invalidate()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            strokes.add(redoStack.removeAt(redoStack.size - 1))
            invalidate()
        }
    }

    fun resetView() {
        camX = 0.0
        camY = 0.0
        scale = 1.0
        invalidate()
    }
}
