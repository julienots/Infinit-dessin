# Dessin Infini

Application Android de dessin où l'on peut zoomer quasi à l'infini dans le
dessin et continuer à dessiner avec précision, même très zoomé.

## Comment ça marche (zoom infini)

Les traits ne sont pas stockés en pixels mais en **coordonnées "monde"**
(nombres `Double`). L'affichage recalcule à chaque frame la position écran
d'un point en le rapportant à la caméra actuelle (`point - caméra`), ce qui
garde toujours des nombres petits et précis, même après un zoom énorme.
En pratique, on peut zoomer jusqu'à environ 10^14 fois avant de sentir une
perte de précision (limite physique des nombres `Double`).

- 1 doigt : dessiner
- 2 doigts : pincer pour zoomer / déplacer la vue

## Publicité

Le projet intègre Google AdMob (bannière en bas de l'écran) avec les
**identifiants de test officiels de Google**. Avant de publier
l'application, remplace :

- `ca-app-pub-3940256099942544~3347511713` dans `AndroidManifest.xml`
- `ca-app-pub-3940256099942544/6300978111` dans `activity_main.xml`

par tes propres identifiants AdMob (créés sur https://admob.google.com).

## Compiler l'APK sur GitHub

1. Crée un dépôt GitHub et pousse tout le contenu de ce dossier à la racine
   du dépôt (le fichier `.github/workflows/build.yml` doit se trouver à
   `.github/workflows/build.yml` dans le dépôt).
2. Va dans l'onglet **Actions** du dépôt : le workflow "Build APK" se lance
   automatiquement à chaque push sur `main` (ou lance-le manuellement via
   "Run workflow").
3. Une fois terminé, télécharge l'APK dans l'artifact **dessin-infini-apk**
   généré par le job.

## Compiler en local (optionnel)

```bash
./gradlew assembleDebug
```
L'APK se trouve ensuite dans `app/build/outputs/apk/debug/app-debug.apk`.
