package com.dessininfini.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow

/**
 * Vue de dessin à "zoom infini".
 *
 * Toutes les coordonnées des traits sont stockées en "coordonnées monde" (Double),
 * jamais en pixels écran. On ne convertit en pixels (Float) qu'au moment du rendu,
 * en soustrayant d'abord la position de la caméra : les nombres manipulés par
 * Canvas restent donc toujours petits et précis, même après un zoom énorme,
 * puisque le point affiché est toujours proche du centre de la caméra.
 *
 * Limite pratique : la précision d'un Double (~15-17 chiffres significatifs)
 * permet de zoomer jusqu'à environ 10^14 fois sans perte visible de précision,
 * ce qui donne l'impression d'un dessin infiniment profond.
 *
 * Le dessin (traits + fond + grille + caméra) peut être exporté/importé au
 * format ".inF" (voir toJson()/loadFromJson()) pour être sauvegardé sur
 * l'appareil et rouvert plus tard, y compris dans d'autres applications
 * compatibles avec ce format.
 */
class InfiniteCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    data class DPoint(val x: Double, val y: Double)

    data class Stroke(
        val color: Int,
        val widthWorld: Double,
        val points: MutableList<DPoint> = mutableListOf()
    )

    private val strokes = mutableListOf<Stroke>()
    private val redoStack = mutableListOf<Stroke>()
    private var currentStroke: Stroke? = null

    /** Position de la caméra en coordonnées monde (centre de l'écran). */
    var camX = 0.0
    var camY = 0.0

    /** Echelle : pixels écran par unité "monde". */
    var scale = 1.0
        private set

    var currentColor = Color.BLACK

    /**
     * Epaisseur de trait choisie par l'utilisateur, exprimée en pixels écran
     * AU MOMENT où le trait est dessiné. Elle est ensuite convertie et figée
     * en unité "monde" (widthWorld = épaisseur / scale) pour que chaque trait
     * garde sa taille relative au dessin, quel que soit le zoom appliqué
     * plus tard.
     */
    var currentThicknessPx: Float = 6f

    /** Couleur de fond du canevas (derrière tous les traits). */
    var backgroundColor: Int = Color.WHITE
        set(value) {
            field = value
            invalidate()
        }

    /** Affiche ou non une grille de repère qui s'adapte au niveau de zoom. */
    var showGrid: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    private val minScale = 1e-6
    private val maxScale = 1e14

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private val gridPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {

            private var lastFocusX = 0f
            private var lastFocusY = 0f
            private var first = true

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                lastFocusX = detector.focusX
                lastFocusY = detector.focusY
                first = true
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val fx = detector.focusX
                val fy = detector.focusY

                if (first) {
                    lastFocusX = fx
                    lastFocusY = fy
                    first = false
                }

                // Point du monde sous le doigt AVANT le changement d'échelle.
                val worldXBefore = camX + (lastFocusX - width / 2.0) / scale
                val worldYBefore = camY + (lastFocusY - height / 2.0) / scale

                var newScale = scale * detector.scaleFactor.toDouble()
                if (newScale < minScale) newScale = minScale
                if (newScale > maxScale) newScale = maxScale
                scale = newScale

                // On replace la caméra pour que ce même point reste sous le doigt.
                camX = worldXBefore - (fx - width / 2.0) / scale
                camY = worldYBefore - (fy - height / 2.0) / scale

                // Déplacement (pan à deux doigts).
                camX -= (fx - lastFocusX) / scale
                camY -= (fy - lastFocusY) / scale

                lastFocusX = fx
                lastFocusY = fy

                invalidate()
                return true
            }
        }
    )

    private fun screenToWorld(sx: Float, sy: Float): DPoint {
        val wx = camX + (sx - width / 2.0) / scale
        val wy = camY + (sy - height / 2.0) / scale
        return DPoint(wx, wy)
    }

    /** Renvoie les coordonnées écran (Float) d'un point monde, relatives à la caméra actuelle. */
    private fun worldToScreen(p: DPoint): FloatArray {
        val sx = ((p.x - camX) * scale + width / 2.0).toFloat()
        val sy = ((p.y - camY) * scale + height / 2.0).toFloat()
        return floatArrayOf(sx, sy)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        if (event.pointerCount >= 2) {
            // Deux doigts = navigation (zoom/déplacement), on annule un trait en cours.
            currentStroke = null
            return true
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val w = screenToWorld(event.x, event.y)
                val widthWorld = currentThicknessPx.toDouble() / scale
                val stroke = Stroke(currentColor, widthWorld)
                stroke.points.add(w)
                currentStroke = stroke
                redoStack.clear()
            }

            MotionEvent.ACTION_MOVE -> {
                currentStroke?.points?.add(screenToWorld(event.x, event.y))
                invalidate()
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                currentStroke?.let {
                    if (it.points.size == 1) {
                        it.points.add(it.points[0])
                    }
                    strokes.add(it)
                }
                currentStroke = null
                invalidate()
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(backgroundColor)

        if (showGrid) drawGrid(canvas)

        for (stroke in strokes) drawStroke(canvas, stroke)
        currentStroke?.let { drawStroke(canvas, it) }
    }

    /**
     * Dessine une grille dont l'espacement "monde" est recalculé à chaque
     * frame comme une puissance de 10 proche de l'échelle actuelle, ce qui
     * donne un repère visuel de profondeur qui reste lisible à n'importe
     * quel niveau de zoom (même x10^14).
     */
    private fun drawGrid(canvas: Canvas) {
        if (width == 0 || height == 0) return

        val targetPx = 120.0
        val rawSpacing = targetPx / scale
        val exponent = floor(ln(rawSpacing) / ln(10.0))
        var spacing = 10.0.pow(exponent)
        // Affine pour rester proche de la cible (évite une grille trop dense ou trop clairsemée).
        if (spacing * scale < targetPx / 2.0) spacing *= 10.0
        if (spacing * scale > targetPx * 5.0) spacing /= 10.0

        val leftWorld = camX - (width / 2.0) / scale
        val rightWorld = camX + (width / 2.0) / scale
        val topWorld = camY - (height / 2.0) / scale
        val bottomWorld = camY + (height / 2.0) / scale

        val isDark = isColorDark(backgroundColor)
        gridPaint.color = if (isDark) Color.argb(60, 255, 255, 255) else Color.argb(50, 0, 0, 0)

        var x = floor(leftWorld / spacing) * spacing
        while (x <= rightWorld) {
            val sx = ((x - camX) * scale + width / 2.0).toFloat()
            canvas.drawLine(sx, 0f, sx, height.toFloat(), gridPaint)
            x += spacing
        }

        var y = floor(topWorld / spacing) * spacing
        while (y <= bottomWorld) {
            val sy = ((y - camY) * scale + height / 2.0).toFloat()
            canvas.drawLine(0f, sy, width.toFloat(), sy, gridPaint)
            y += spacing
        }
    }

    private fun isColorDark(color: Int): Boolean {
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)
        val luminance = (0.299 * r + 0.587 * g + 0.114 * b)
        return luminance < 128
    }

    private fun drawStroke(canvas: Canvas, stroke: Stroke) {
        if (stroke.points.isEmpty()) return

        paint.color = stroke.color
        val strokeWidthPx = (stroke.widthWorld * scale).toFloat()
        paint.strokeWidth = if (strokeWidthPx < 1.5f) 1.5f else strokeWidthPx

        if (stroke.points.size == 1) {
            val p = worldToScreen(stroke.points[0])
            canvas.drawPoint(p[0], p[1], paint)
            return
        }

        val path = Path()
        val first = worldToScreen(stroke.points[0])
        path.moveTo(first[0], first[1])
        for (i in 1 until stroke.points.size) {
            val p = worldToScreen(stroke.points[i])
            path.lineTo(p[0], p[1])
        }
        canvas.drawPath(path, paint)
    }

    fun clearAll() {
        strokes.clear()
        redoStack.clear()
        currentStroke = null
        invalidate()
    }

    fun undo() {
        if (strokes.isNotEmpty()) {
            redoStack.add(strokes.removeAt(strokes.size - 1))
            invalidate()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            strokes.add(redoStack.removeAt(redoStack.size - 1))
            invalidate()
        }
    }

    fun resetView() {
        camX = 0.0
        camY = 0.0
        scale = 1.0
        invalidate()
    }

    // ------------------------------------------------------------------
    // Format de fichier ".inF" (Infinite Image)
    //
    // JSON versionné, indépendant de la plateforme, pensé pour être relu
    // par n'importe quelle autre application (dessin, visionneuse, etc.)
    // qui voudrait ouvrir des "images infinies" :
    //
    // {
    //   "format": "InfiniteImage",
    //   "version": 1,
    //   "background": { "color": "#FFFFFFFF", "grid": true },
    //   "camera": { "x": 0.0, "y": 0.0, "scale": 1.0 },
    //   "strokes": [
    //     { "color": "#FF000000", "width": 0.5, "points": [[x,y], [x,y], ...] }
    //   ]
    // }
    //
    // - Les couleurs sont en hexadécimal ARGB ("#AARRGGBB").
    // - "width" est l'épaisseur du trait en unité MONDE (pas en pixels),
    //   ce qui est ce qui permet à un même fichier .inF d'être zoomé à
    //   l'infini sans que les traits ne deviennent flous ou disproportionnés.
    // - Les champs inconnus doivent être ignorés par les lecteurs futurs
    //   pour rester compatibles avec des versions ultérieures du format.
    // ------------------------------------------------------------------

    private fun colorToHex(color: Int): String = String.format("#%08X", color)

    fun toJson(): JSONObject {
        val root = JSONObject()
        root.put("format", "InfiniteImage")
        root.put("version", 1)

        val background = JSONObject()
        background.put("color", colorToHex(backgroundColor))
        background.put("grid", showGrid)
        root.put("background", background)

        val camera = JSONObject()
        camera.put("x", camX)
        camera.put("y", camY)
        camera.put("scale", scale)
        root.put("camera", camera)

        val strokesArray = JSONArray()
        for (stroke in strokes) {
            val strokeObj = JSONObject()
            strokeObj.put("color", colorToHex(stroke.color))
            strokeObj.put("width", stroke.widthWorld)
            val pointsArray = JSONArray()
            for (p in stroke.points) {
                val pointArray = JSONArray()
                pointArray.put(p.x)
                pointArray.put(p.y)
                pointsArray.put(pointArray)
            }
            strokeObj.put("points", pointsArray)
            strokesArray.put(strokeObj)
        }
        root.put("strokes", strokesArray)

        return root
    }

    /**
     * Recharge un dessin depuis un JSON conforme au format ".inF".
     * Lève une exception si le format n'est pas reconnu, à charge de
     * l'appelant d'afficher un message d'erreur clair à l'utilisateur.
     */
    fun loadFromJson(root: JSONObject) {
        val format = root.optString("format", "")
        require(format == "InfiniteImage") { "Fichier .inF invalide (format inconnu)" }

        strokes.clear()
        redoStack.clear()
        currentStroke = null

        val background = root.optJSONObject("background")
        if (background != null) {
            val colorStr = background.optString("color", "#FFFFFFFF")
            backgroundColor = try {
                Color.parseColor(colorStr)
            } catch (e: IllegalArgumentException) {
                Color.WHITE
            }
            showGrid = background.optBoolean("grid", true)
        }

        val camera = root.optJSONObject("camera")
        if (camera != null) {
            camX = camera.optDouble("x", 0.0)
            camY = camera.optDouble("y", 0.0)
            var loadedScale = camera.optDouble("scale", 1.0)
            if (loadedScale < minScale) loadedScale = minScale
            if (loadedScale > maxScale) loadedScale = maxScale
            scale = loadedScale
        }

        val strokesArray = root.optJSONArray("strokes")
        if (strokesArray != null) {
            for (i in 0 until strokesArray.length()) {
                val strokeObj = strokesArray.getJSONObject(i)
                val color = try {
                    Color.parseColor(strokeObj.optString("color", "#FF000000"))
                } catch (e: IllegalArgumentException) {
                    Color.BLACK
                }
                val widthWorld = strokeObj.optDouble("width", 1.0)
                val stroke = Stroke(color, widthWorld)

                val pointsArray = strokeObj.optJSONArray("points")
                if (pointsArray != null) {
                    for (j in 0 until pointsArray.length()) {
                        val pointArray = pointsArray.getJSONArray(j)
                        val x = pointArray.getDouble(0)
                        val y = pointArray.getDouble(1)
                        stroke.points.add(DPoint(x, y))
                    }
                }
                strokes.add(stroke)
            }
        }

        invalidate()
    }
}
