package com.dessininfini.app

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var canvasView: InfiniteCanvasView

    /** Palette de fonds proposée au bouton "Fond" (cycle à chaque appui). */
    private val backgroundPalette = intArrayOf(
        Color.WHITE,
        Color.BLACK,
        Color.rgb(230, 230, 230),
        Color.rgb(40, 40, 60)
    )
    private var backgroundIndex = 0

    /** Epaisseurs proposées, en pixels écran au moment du tracé. */
    private val thicknessThin = 2f
    private val thicknessMedium = 6f
    private val thicknessThick = 16f

    // Sélecteur système pour choisir OÙ enregistrer un nouveau fichier .inF.
    private val createDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null) saveToUri(uri) else toast("Sauvegarde annulée")
    }

    // Sélecteur système pour choisir QUEL fichier .inF ouvrir.
    private val openDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) loadFromUri(uri) else toast("Ouverture annulée")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MobileAds.initialize(this) {}

        canvasView = findViewById(R.id.canvasView)
        canvasView.backgroundColor = backgroundPalette[backgroundIndex]

        findViewById<Button>(R.id.btnNoir).setOnClickListener {
            canvasView.currentColor = Color.BLACK
        }
        findViewById<Button>(R.id.btnRouge).setOnClickListener {
            canvasView.currentColor = Color.RED
        }
        findViewById<Button>(R.id.btnBleu).setOnClickListener {
            canvasView.currentColor = Color.BLUE
        }
        findViewById<Button>(R.id.btnVert).setOnClickListener {
            canvasView.currentColor = Color.rgb(0, 150, 0)
        }
        findViewById<Button>(R.id.btnUndo).setOnClickListener {
            canvasView.undo()
        }
        findViewById<Button>(R.id.btnRedo).setOnClickListener {
            canvasView.redo()
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            canvasView.clearAll()
        }
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            canvasView.resetView()
        }

        findViewById<Button>(R.id.btnFin).setOnClickListener {
            canvasView.currentThicknessPx = thicknessThin
        }
        findViewById<Button>(R.id.btnMoyen).setOnClickListener {
            canvasView.currentThicknessPx = thicknessMedium
        }
        findViewById<Button>(R.id.btnEpais).setOnClickListener {
            canvasView.currentThicknessPx = thicknessThick
        }

        findViewById<Button>(R.id.btnFond).setOnClickListener {
            backgroundIndex = (backgroundIndex + 1) % backgroundPalette.size
            canvasView.backgroundColor = backgroundPalette[backgroundIndex]
        }
        findViewById<Button>(R.id.btnGrille).setOnClickListener {
            canvasView.showGrid = !canvasView.showGrid
        }

        findViewById<Button>(R.id.btnSauver).setOnClickListener {
            createDocumentLauncher.launch("dessin.inF")
        }
        findViewById<Button>(R.id.btnOuvrir).setOnClickListener {
            openDocumentLauncher.launch(arrayOf("*/*"))
        }

        val adView = findViewById<AdView>(R.id.adView)
        adView.loadAd(AdRequest.Builder().build())

        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    /**
     * Si l'app est ouverte depuis un gestionnaire de fichiers (ou une autre
     * app) sur un fichier ".inF", on le charge automatiquement.
     */
    private fun handleIncomingIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        loadFromUri(uri)
    }

    private fun saveToUri(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { output ->
                val json = canvasView.toJson()
                output.write(json.toString(2).toByteArray(Charsets.UTF_8))
            }
            toast("Dessin sauvegardé (.inF)")
        } catch (e: Exception) {
            toast("Erreur à la sauvegarde : ${e.message}")
        }
    }

    private fun loadFromUri(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                val text = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                val json = JSONObject(text)
                canvasView.loadFromJson(json)
            }
            toast("Dessin chargé")
        } catch (e: Exception) {
            toast("Fichier .inF illisible : ${e.message}")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
